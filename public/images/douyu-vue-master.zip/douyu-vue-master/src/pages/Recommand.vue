<template>
    <div class="mr-root">
       <public-header>
         <p class="title">推荐</p>
       </public-header>
       <div class="mr-content">
         该页面正在开发中,敬请期待...
       </div>
    </div>
</template>

<script>
    import PublicHeader from '../components/Header'
    export default {
        components:{
            PublicHeader
        }
    }
</script>

<style>

</style>
