/**
 * Created by 周军鹏 on 2017/3/2.
 */
import Vue from 'vue'
var bus = new Vue()
export default bus
