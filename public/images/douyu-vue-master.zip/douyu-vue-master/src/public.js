/**
 * Created by 周军鹏 on 2017/3/3.
 */
import PublicHeader from './components/Header'
import Loading from './components/Loading'

export default {
  components:{
    PublicHeader,Loading
  }
}
